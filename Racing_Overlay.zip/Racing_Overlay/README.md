# ALTTPR Race Overlay

A standalone OBS overlay: the classic 5×8 item board, driven entirely by a
tracker's Items API. It shares no code and no channel with the tracker windows,
so it can run on a different machine, or against a different tracker, as long as
that tracker publishes the same API.

## Hutch-tracker
Enable the Items API -> Launcher go to the settings (upper right hand corner), and enable the Items API. 

## Hoell-tracker
The API is enabled all the time.  Nothing to change. NOTE: there is no go mode button, so it will never light up. 

## Use it

Add a **Browser Source** in OBS pointing at `overlay.html`:

```
file:///…/race-overlay/overlay.html
```

Set the source to 700 × 440 (or use `?scale=` below), and tick
"Shutdown source when not visible" off so it keeps its connection.

In the tracker's launcher, App Settings → **Items API** must be enabled. The
overlay's defaults match the launcher's: REST on `8720`, WebSocket on `8201`.

## URL options

| Option | Default | What it does |
|---|---|---|
| `host` | `127.0.0.1` | The machine running the tracker |
| `ws` | `8201` | WebSocket port (live push) |
| `port` | `8720` | REST port (fallback polling) |
| `items` | `items` | Folder the icons are read from |
| `scale` | `1` | Whole-board scale, e.g. `0.75` |
| `status` | on | `status=off` hides the connection dot |

Example, streaming PC pointed at the game PC:

```
overlay.html?host=192.168.1.20&scale=0.8&status=off
```

## How it gets data

WebSocket first: on connect the server sends
`{ type: 'full-state', data: { <channel>: <payload> } }`, then one message per
channel that changes. The overlay reads two channels:

* `sni:item-update` — item levels/flags
* `sni:dungeon-update` — per-dungeon `prizeType` and `prizeCollected`

plus the three channels that carry the streamer's own marks:

* `tracker:prize-change` — `{ dungeonId, prizeType }`
* `tracker:medallions` / `tracker:medallion-change` — the MM and TR medallions
* `tracker:seed-reset` — clears prizes, medallions and collected state

These are the HoellTracker channel shapes, which is why this overlay works
against any tracker that speaks them. Note that HoellTracker puts `prizeType`
only in the connect snapshot and sends every later change on
`tracker:prize-change`, so the overlay remembers prizes itself rather than
re-reading them from each dungeon message — a routine progress update with no
`prizeType` in it never wipes a prize.

The medallion shows as a small icon in the corner of the MM and TR cells.

If the socket can't be opened it falls back to polling `GET /items` and
`GET /dungeons` on the REST port once a second, and switches back to the socket
the moment it comes up. The dot in the bottom-right corner is green while data
is arriving, red when it isn't.

Fields beyond the HoellTracker set that this overlay uses when present:
`halfmagic`, `crystals`, `gomode` (the GO badge lights from `gomode`; a tracker
that doesn't send it simply leaves the badge dark).

## Icons

`items/` holds the 85 PNGs the board needs, copied from the tracker. Point the
`items` URL option somewhere else to theme it — the file names are the tracker's
own (`sword3.png`, `bottle_empty.png`, `redcrystal1.png`, …).
